package com.tweetapp.tweets.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetapp.tweets.entity.Like;

public interface LikeRepository extends MongoRepository<Like, Long>{
	
	List<Like> findByTweetId(Long id);
	void deleteByTweetId(Long id);

}
