package com.tweetapp.tweets.service;

import java.util.List;

import com.tweetapp.tweets.entity.Tweet;

public interface TweetService {
	
	public Tweet postTweet(Tweet tweet);
	
	public String updateTweet(String userName,Long id,Tweet tweet);
	
	public List<Tweet> getAllTweets();
	
	public List<Tweet> getAllTweetByUser(String userName);
	
	public String deleteTweet(String userId,Long id);

}
