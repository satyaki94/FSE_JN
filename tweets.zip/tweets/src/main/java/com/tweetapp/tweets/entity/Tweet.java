package com.tweetapp.tweets.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection  = "Tweets")
public class Tweet {
	
	@Transient
    public static final String SEQUENCE_NAME = "tweet_sequence";

	@Id
	private Long tweetId;
	private String tweetMsg;
	private String tweetBy;
	private Date tweetAt;
	private List<Reply> replies;
	private List<Like> likes;
	
	
	
	@Override
	public String toString() {
		return "Tweet [tweetId=" + tweetId + ", tweetMsg=" + tweetMsg + ", tweetBy=" + tweetBy + ", tweetAt=" + tweetAt
				+ ", replies=" + replies + ", likes=" + likes + "]";
	}
	public List<Like> getLikes() {
		return likes;
	}
	public void setLikes(List<Like> likes) {
		this.likes = likes;
	}
	public Long getTweetId() {
		return tweetId;
	}
	public void setTweetId(Long tweetId) {
		this.tweetId = tweetId;
	}
	public String getTweetMsg() {
		return tweetMsg;
	}
	public void setTweetMsg(String tweetMsg) {
		this.tweetMsg = tweetMsg;
	}
	public String getTweetBy() {
		return tweetBy;
	}
	public void setTweetBy(String tweetBy) {
		this.tweetBy = tweetBy;
	}
	public Date getTweetAt() {
		return tweetAt;
	}
	public void setTweetAt(Date tweetAt) {
		this.tweetAt = tweetAt;
	}
	public List<Reply> getReplies() {
		return replies;
	}
	public void setReplies(List<Reply> replies) {
		this.replies = replies;
	}
	
	
	
}
