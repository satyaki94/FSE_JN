package com.tweetapp.tweets.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweets.entity.Reply;
import com.tweetapp.tweets.service.ReplyService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/reply")
@Api(value = "Reply Level Endpoints")
public class ReplyControllerAPI {
	
	@Autowired
	private ReplyService replyService;

	@PostMapping("/{userName}/reply/{id}")
	@ApiOperation(value = "Reply to a Tweet",notes="Reply a Tweet.")
	@ApiResponses({@ApiResponse(code = 201,message = "Replied")})
	public ResponseEntity<?> postTweet(@RequestBody Reply reply,@PathVariable String userName,
			@PathVariable Long id) {
		
		
		return ResponseEntity.ok().body(replyService.postReply(userName, id,reply));
		
		
	}
	
	@PostMapping("/{userName}/like/{id}")
	@ApiOperation(value = "Like a Tweet",notes="Like a Tweet.")
	@ApiResponses({@ApiResponse(code = 201,message = "Liked")})
	public ResponseEntity<?> postLike(@PathVariable String userName,
			@PathVariable Long id) {
		
		
		return ResponseEntity.ok().body(replyService.postLike(userName, id));
		
		
	}
	
	
}
