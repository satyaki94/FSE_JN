package com.tweetapp.tweets.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Like {
	
	@Transient
    public static final String SEQUENCE_NAME = "like_sequence";

	@Id
	private Long likeId;
	private Long tweetId;
	private String userId;
	
	
	@Override
	public String toString() {
		return "Like [likeId=" + likeId + ", tweetId=" + tweetId + ", userId=" + userId + "]";
	}
	public Long getLikeId() {
		return likeId;
	}
	public void setLikeId(Long likeId) {
		this.likeId = likeId;
	}
	public Long getTweetId() {
		return tweetId;
	}
	public void setTweetId(Long tweetId) {
		this.tweetId = tweetId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	
}
