package com.tweetapp.tweets.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweets.entity.Tweet;
import com.tweetapp.tweets.service.TweetService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/tweets")
@Api(value = "Tweet Level Endpoints")
public class TweetControllerAPI {
	
	@Autowired
	private TweetService tweetService;
	
	
		
	@PostMapping("/{userName}/add")
	@ApiOperation(value = "Post a Tweet",notes="Post a new Tweet.")
	@ApiResponses({@ApiResponse(code = 201,message = "Tweet Posted")})
	public ResponseEntity<?> postTweet(@RequestBody Tweet tweet,@PathVariable String userName) {
		
		tweet.setTweetBy(userName);
		Tweet tweetTemp= tweetService.postTweet(tweet);
		return ResponseEntity.ok().body(tweetTemp);
		
		
	}
	
	@GetMapping("/all")
	@ApiOperation(value = "Get All Tweets",notes = "Get All tweets by all Users")
	@ApiResponses({@ApiResponse(code = 200, message = "All Tweet Listed",response = List.class)})
	public List<Tweet> getTweets(){
		return tweetService.getAllTweets();
	}
	
	
	
	@GetMapping("/{userName}")
	@ApiOperation(value = "Get All Tweets by an User",notes = "Get All tweets by an User")
	@ApiResponses({@ApiResponse(code = 200, message = "All Tweet Listed by user",response = List.class)})
	public List<Tweet> getTweetsByUser(@PathVariable String userName){
		return tweetService.getAllTweetByUser(userName);
	}
	
	@PutMapping("/{userName}/update/{id}")
	@ApiOperation(value = "Update Tweet by an User",notes = "Update Tweet by an User")
	@ApiResponses({@ApiResponse(code = 200, message = "Tweet Updated Successfully")})
	public ResponseEntity<?> updateTweet(@RequestBody Tweet tweet,@PathVariable String userName,@PathVariable Long id){
		return ResponseEntity.ok(tweetService.updateTweet(userName,id,tweet));
	}
	
	@DeleteMapping("/{userName}/delete/{id}")
	@ApiOperation(value = "Delete Tweet by an User",notes = "Delete by an User")
	@ApiResponses({@ApiResponse(code = 200, message = "Tweet Deleted Successfully")})
	public ResponseEntity<?> deleteTweet(@PathVariable String userName,@PathVariable Long id){
		
		return ResponseEntity.ok(tweetService.deleteTweet(userName,id));
	}
	
	

}
