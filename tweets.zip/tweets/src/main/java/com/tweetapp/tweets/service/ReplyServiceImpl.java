package com.tweetapp.tweets.service;

import java.sql.Timestamp;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.tweets.entity.Like;
import com.tweetapp.tweets.entity.Reply;
import com.tweetapp.tweets.entity.Tweet;
import com.tweetapp.tweets.repository.LikeRepository;
import com.tweetapp.tweets.repository.ReplyRepository;
import com.tweetapp.tweets.repository.TweetRepository;

@Service
public class ReplyServiceImpl implements ReplyService{


	
	@Autowired
	private ReplyRepository replyRepository;
	
	@Autowired
	private TweetRepository tweetRepository;
	
	@Autowired
	private LikeRepository likeRepository;
	
	@Autowired
	private SequenceGeneratorService sequenceGeneratorService;
	
	@Override
	public String postReply(String userName, Long id, Reply reply) {
		//Check if Tweet is present on the Id
		Optional<Tweet> tweet= tweetRepository.findById(id);
		if (tweet.isPresent()) {
			reply.setReplyId(sequenceGeneratorService.generateSequence(Reply.SEQUENCE_NAME));
			reply.setReplyBy(userName);
			reply.setTweetId(id);
			reply.setReplyOn(new Timestamp(System.currentTimeMillis()));
			replyRepository.save(reply);
			return "Replied Successfully";
		}else {
			return"Can not reply to a Tweet that is yet to be posted.";
		}
		
	}

	@Override
	public String postLike(String userName, Long id) {
		//Check if Tweet is present on the Id
				Optional<Tweet> tweet= tweetRepository.findById(id);
				if (tweet.isPresent()) {
					Like like=new Like();
					like.setLikeId(sequenceGeneratorService.generateSequence(Like.SEQUENCE_NAME));
					like.setTweetId(id);
					like.setUserId(userName);
					likeRepository.save(like);
					
					return "You have liked it !..";
					
				}else {
					return"Can not like a Tweet that is yet to be posted.";
				}
	}
	

}
