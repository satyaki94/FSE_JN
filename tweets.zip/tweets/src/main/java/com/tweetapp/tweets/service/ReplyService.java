package com.tweetapp.tweets.service;

import com.tweetapp.tweets.entity.Reply;

public interface ReplyService {
	
	public String postReply(String userName, Long id, Reply reply);
	
	public String postLike(String userName, Long id);

}
