package com.tweetapp.tweets.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.tweetapp.tweets.entity.Like;
import com.tweetapp.tweets.entity.Reply;
import com.tweetapp.tweets.entity.Tweet;
import com.tweetapp.tweets.repository.LikeRepository;
import com.tweetapp.tweets.repository.ReplyRepository;
import com.tweetapp.tweets.repository.TweetRepository;


@Service("tweetService")
public class TweetServiceImpl implements TweetService {
	
	
	
	@Autowired
	private TweetRepository tweetRepository;
	
	@Autowired
	private ReplyRepository replyRepository;
	
	@Autowired
	private LikeRepository likeRepository;
	
	
	
	@Autowired
	MongoTemplate mongoTemplate;
	

	@Autowired
	private SequenceGeneratorService sequenceGeneratorService;
	
	

	@Override
	public Tweet postTweet(Tweet tweet) {
	
	tweet.setTweetId(sequenceGeneratorService.generateSequence(Tweet.SEQUENCE_NAME));
	tweet.setTweetAt(new Timestamp(System.currentTimeMillis()));
	return tweetRepository.save(tweet);
	
	}

	
	@Override
	public List<Tweet> getAllTweets() {
		List<Tweet> tweetList= tweetRepository.findAll();
		List<Reply> replyList=new ArrayList<>();
		List<Like> likeList=new ArrayList<>();
		for(Tweet indTweet : tweetList) {
			replyList=replyRepository.findByTweetId(indTweet.getTweetId());
			indTweet.setReplies(replyList);
			likeList=likeRepository.findByTweetId(indTweet.getTweetId());
			indTweet.setLikes(likeList);
			
		}
		return tweetList;	
		
	}

	@Override
	public List<Tweet> getAllTweetByUser(String userName) {
		
		List<Tweet> tweetList= tweetRepository.findByTweetBy(userName);
		List<Reply> replyList=new ArrayList<>();
		List<Like> likeList=new ArrayList<>();
		for(Tweet indTweet : tweetList) {
			replyList=replyRepository.findByTweetId(indTweet.getTweetId());
			indTweet.setReplies(replyList);
			likeList=likeRepository.findByTweetId(indTweet.getTweetId());
			indTweet.setLikes(likeList);
		}
		return tweetList;
	}

	@Override
	public String deleteTweet(String userId,Long id) {
		
		Query query=new Query();
		query.addCriteria(Criteria.where("tweetBy").is(userId).and("tweetId").is(id));
		List<Tweet> tweets=mongoTemplate.find(query, Tweet.class);
		if (!tweets.isEmpty()) {
			tweetRepository.deleteAll(tweets);
			replyRepository.deleteByTweetId(tweets.get(0).getTweetId());
			likeRepository.deleteByTweetId(tweets.get(0).getTweetId());
			return "Deleted Successfully.";
		}else {
			return "No Data Deleted.";
		}
		
		
		
	}


	@Override
	public String updateTweet(String userName, Long id,Tweet tweet) {
		Query query=new Query();
		query.addCriteria(Criteria.where("tweetBy").is(userName).and("tweetId").is(id));
		
		Update update=new Update();
		update.set("tweetMsg", tweet.getTweetMsg());
		update.set("tweetAt", new Timestamp(System.currentTimeMillis()));
		mongoTemplate.update(Tweet.class).matching(query).apply(update).first();
		
		return "Update Successful";
	}

}
