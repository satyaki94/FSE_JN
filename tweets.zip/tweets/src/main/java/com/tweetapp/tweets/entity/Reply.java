package com.tweetapp.tweets.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Reply")
public class Reply {
	
	@Transient
    public static final String SEQUENCE_NAME = "reply_sequence";
	

	@Id
	private Long replyId;
	private Long tweetId;
	private String replyMsg;
	private String replyBy;
	private Date replyOn;
	
	
	
	
	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", tweetId=" + tweetId + ", replyMsg=" + replyMsg + ", replyBy=" + replyBy
				+ ", replyOn=" + replyOn + "]";
	}
	public Long getTweetId() {
		return tweetId;
	}
	public void setTweetId(Long tweetId) {
		this.tweetId = tweetId;
	}
	public Long getReplyId() {
		return replyId;
	}
	public void setReplyId(Long replyId) {
		this.replyId = replyId;
	}
	public String getReplyMsg() {
		return replyMsg;
	}
	public void setReplyMsg(String replyMsg) {
		this.replyMsg = replyMsg;
	}
	public String getReplyBy() {
		return replyBy;
	}
	public void setReplyBy(String replyBy) {
		this.replyBy = replyBy;
	}
	public Date getReplyOn() {
		return replyOn;
	}
	public void setReplyOn(Date replyOn) {
		this.replyOn = replyOn;
	}
	
	
}
