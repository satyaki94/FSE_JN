package com.tweetapp.tweets.repository;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetapp.tweets.entity.Tweet;

public interface TweetRepository extends MongoRepository<Tweet, Long> {
	
	List<Tweet>findByTweetBy(String userName);
	

}
