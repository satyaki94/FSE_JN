package com.tweetapp.tweets.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetapp.tweets.entity.Reply;

public interface ReplyRepository extends MongoRepository<Reply, Long> {
	
	List<Reply> findByTweetId(Long id);
	void deleteByTweetId(Long id);

}
